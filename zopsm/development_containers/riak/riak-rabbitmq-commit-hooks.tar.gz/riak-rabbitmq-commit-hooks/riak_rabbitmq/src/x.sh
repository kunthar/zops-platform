#!/usr/bin/env bash

/usr/lib/riak/erts-5.10.3/bin/erlc riak_rabbitmq.erl
mv riak_rabbitmq.beam ../ebin

sudo service riak restart
