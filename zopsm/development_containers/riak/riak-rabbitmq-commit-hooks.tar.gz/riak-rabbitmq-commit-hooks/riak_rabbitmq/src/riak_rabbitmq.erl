-module(riak_rabbitmq).
-include_lib("amqp_client/include/amqp_client.hrl").
-include_lib("eredis/include/eredis.hrl").

-export([
  postcommit_send_amqp/1
]).

-define(BUCKET_META, <<"AMQP-Meta">>).
-define(DELETED, <<"X-Riak-Deleted">>).
-define(META, <<"X-Riak-Meta">>).
-define(EXCHANGE, <<"X-Riak-Meta-Amqp-Exchange">>).
-define(ROUTING_KEY, <<"X-Riak-Meta-Amqp-Routing-Key">>).
-define(HOST, <<"X-Riak-Meta-Amqp-Host">>).
-define(PORT, <<"X-Riak-Meta-Amqp-Port">>).
-define(VHOST, <<"X-Riak-Meta-Amqp-Vhost">>).
-define(USER, <<"X-Riak-Meta-Amqp-User">>).
-define(REDIS_HOST, <<"X-Riak-Meta-Amqp-Redis-Host">>).
-define(PASSWORD, <<"X-Riak-Meta-Amqp-Password">>).
-define(SKIP, <<"X-Riak-Meta-Amqp-Ignore">>).
-define(CONTENT_TYPE, <<"content-type">>).

postcommit_send_amqp(RObj) ->

  MetadataObj = riak_object:get_metadata(RObj),
  Headers = key_find(?META, MetadataObj, none, []),
  % io:format("Obj meta: ~p~n", [MetadataObj]),
  % io:format("Obj headers: ~p~n", [Headers]),

  {ok, C} = riak:local_client(),
  PerBucketMetaObj = case C:get(riak_object:bucket(RObj), ?BUCKET_META) of
    {ok, PBMO} -> PBMO;
    _ -> none
  end,

  PerBucketHeaders = case PerBucketMetaObj of
    none -> none;
    _ ->
      PBM = riak_object:get_metadata(PerBucketMetaObj),
      key_find(?META, PBM, none, [])
  end,
  % io:format("bucket meta: ~p~n", [PerBucketHeaders]),

  Exchange = find(?EXCHANGE, Headers, PerBucketHeaders, riak_object:bucket(RObj)),
  ContentType = list_to_binary(key_find(?CONTENT_TYPE, MetadataObj, PerBucketHeaders, "application/octet-stream")),
  Body = riak_object:get_value(RObj),

  % Decode body to get specific key-values
  KV_Body = jiffy:decode(Body),
  TenantId = ej:get({"tenant_id"}, KV_Body),
  ProjectId = ej:get({"project_id"}, KV_Body),
  ServiceId = ej:get({"service_id"}, KV_Body),
  AccountId = ej:get({"account_id"}, KV_Body),
  RoutingKey = ej:get({"receiver"}, KV_Body),

  RObj_Key = riak_object:key(RObj),
  BodyWithRiakKey = ej:set({"riak_key"}, KV_Body, RObj_Key),

  Data = jiffy:encode(BodyWithRiakKey),
 
  % Connect Redis and Check if RoutingKey (Reciver) exists and send the message to reciver.
  RedisHost = binary_to_list(find(?REDIS_HOST, Headers, PerBucketHeaders, riak_object:bucket(RObj))),
  {ok, RC} = eredis:start_link(RedisHost, 6379, 0, ""),
  case byte_size(RoutingKey) of
     0 -> ChannelId = ej:get({"channel"}, KV_Body),
        Publish = #'basic.publish'{ exchange=Exchange, routing_key=ChannelId };
     _ -> 
      Publish = case eredis:q(RC, ["SISMEMBER", string:join(["Tenants", binary_to_list(TenantId), "Accounts", binary_to_list(AccountId), "Projects", binary_to_list(ProjectId), "Services", binary_to_list(ServiceId), "OnlineSubscribers"], ":"), RoutingKey]) of
         {ok, V} ->
            case V of
             <<"1">> -> #'basic.publish'{ exchange=Exchange, routing_key=RoutingKey };
             <<"0">> -> io:format("The user is not found in redis db.")
            end
      end
   end,

  case find(?SKIP, Headers, [], "false") of
    "true" -> ok;
    _ ->
      AppHdrs = lists:foldl(fun ({HdrKey, HdrValue}, NewHdrs) ->
                                <<_:12/binary, Key/binary>> = HdrKey,
                                [{binary_to_list(Key), binary, HdrValue} | NewHdrs]
                            end, [], Headers),
      ExtraHdrs = [case key_find(?DELETED, MetadataObj, none, "false") of
                     "true" -> {"X-Riak-Deleted", binary, "true"};
                     "false" -> []
                   end],
      Props = #'P_basic'{ content_type=ContentType, headers=lists:flatten([AppHdrs, ExtraHdrs]) },

      % Msg = #amqp_msg{ payload=tuple_to_list(Data), props=Props },
      Msg = #amqp_msg{ payload=Data, props=Props },
      % io:format("message: ~p~n", [Props]),
      {ok, Channel} = amqp_channel(Headers, PerBucketHeaders),
      % io:format("channel: ~p~n", [Channel]),
      amqp_channel:cast(Channel, Publish, Msg),
      % io:format("published~n"),
      ok
  end.

amqp_channel(Headers, PerBucketMeta) ->
  AmqpParams = amqp_p(Headers, PerBucketMeta),
  % io:format("amqp params: ~p~n", [AmqpParams]),
  case pg2:get_closest_pid(AmqpParams) of
    {error, {no_such_group, _}} ->
      pg2:create(AmqpParams),
      amqp_channel(Headers, PerBucketMeta);
    {error, {no_process, _}} ->
      % io:format("no client running~n"),
      case amqp_connection:start(AmqpParams) of
        {ok, Client} ->
          % io:format("started new client: ~p~n", [Client]),
          case amqp_connection:open_channel(Client) of
            {ok, Channel} ->
              pg2:join(AmqpParams, Channel),
              {ok, Channel};
            {error, Reason} -> {error, Reason}
          end;
        {error, Reason} ->
          % io:format("encountered an error: ~p~n", [Reason]),
          {error, Reason}
      end;
    Channel ->
      % io:format("using existing channel: ~p~n", [Channel]),
      {ok, Channel}
  end.

amqp_p(Headers, PerBucketHeaders) ->

  % io:format("ObjMeta: ~p~n", [Headers]),
  % io:format("BucketMeta: ~p~n", [PerBucketHeaders]),

  Host = find(?HOST, Headers, PerBucketHeaders, <<"127.0.0.1">>),
  Port = find(?PORT, Headers, PerBucketHeaders, 5672),
  Vhost = find(?VHOST, Headers, PerBucketHeaders, <<"/">>),
  User = find(?USER, Headers, PerBucketHeaders, <<"guest">>),
  Pass = find(?PASSWORD, Headers, PerBucketHeaders, <<"guest">>),

  % io:format([Host,Port,Vhost,User,Pass]),
  #amqp_params_network{username = User,
                       password = Pass,
                       virtual_host = Vhost,
                       host = binary_to_list(Host),
                       port = binary_to_integer(Port)}.


find(K, L, PerBucketHeaders, Default) ->
  case lists:keyfind(K, 1, L) of
    {K, V} -> V;
    _ ->
      case PerBucketHeaders of
        none -> Default;
        _ ->
          case lists:keyfind(K, 1, PerBucketHeaders) of
            {K, BucketV} -> BucketV;
            _ -> Default
          end
      end
  end.

key_find(K, D, PerBucketHeaders, Default) ->
  case dict:find(K, D) of
    {ok, V} -> V;
    _ ->
      % io:format("per-bucket meta: ~p~n", [PerBucketHeaders]),
      case PerBucketHeaders of
        none -> Default;
        _ ->
          case find(K, PerBucketHeaders, none, Default) of
            PerBucketV when is_binary(PerBucketV) -> PerBucketV;
            PerBucketV -> list_to_binary(PerBucketV)
          end
      end
  end.
